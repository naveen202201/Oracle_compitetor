# RFP Analysis Platform

## Overview
A modular Python Flask application that orchestrates 7 AI agents via the Blueverse Foundry API to analyze RFP documents and generate comprehensive competitive intelligence reports.

## Architecture

### Pipeline Flow (Sequential Phases)
```
Phase 1:  RFP Document  -->  [RFP Understanding Agent]  -->  RFP Summary
                                        |
Phase 2:           +--------------------+--------------------+
                   |                                         |
          [Oracle MFG Capability Agent]        [Competitor Intelligence Agent]
                   |                                         |
          Oracle Analysis Report                 Competitor Analysis Report
                   |                                         |
Phase 3:           +------------------+---+------------------+
                   |                  |                       |
     [Battlecard Generator]  [Positioning & Messaging]  [GO/No-Go Agent]
                   |                  |                       |
          Battlecards        Positioning Narratives    Go/No-Go Report
                   |                  |                       |
Phase 4:           +------------------+-----------------------+
                                      |
                       [Recommendation Outcomes Agent]
                                      |
                            Final Recommendation
```

## Project Structure
```
rfp_analysis_platform/
├── .env                          # API endpoints & keys
├── requirements.txt              # Python dependencies
├── run.py                        # Application entry point
├── config.py                     # Centralized configuration
├── README.md                     # This file
├── app/
│   ├── __init__.py               # Flask app factory
│   ├── routes.py                 # API routes & file upload
│   ├── templates/
│   │   └── index.html            # Web UI template
│   └── static/
│       ├── css/style.css         # Dark-themed UI styles
│       └── js/main.js            # Frontend logic
├── agents/
│   ├── __init__.py
│   ├── base_agent.py             # Base agent class (API caller)
│   ├── rfp_understanding.py      # Agent 1
│   ├── oracle_mfg_capability.py  # Agent 2
│   ├── competitor_intelligence.py# Agent 3
│   ├── battlecard_generator.py   # Agent 4
│   ├── positioning_messaging.py  # Agent 5
│   ├── go_nogo.py                # Agent 6
│   ├── recommendation_outcomes.py# Agent 7
│   └── orchestrator.py           # Pipeline orchestrator
├── utils/
│   ├── __init__.py
│   ├── file_parser.py            # PDF/DOCX/TXT text extraction
│   ├── logger_setup.py           # Logging configuration
│   └── report_saver.py           # Save reports to disk
├── outputs/                      # Generated reports (per run)
└── logs/                         # Application logs
```

## Setup & Run

### 1. Install Dependencies
```bash
cd rfp_analysis_platform
pip install -r requirements.txt
```

### 2. Configure API Keys
Edit `.env` and set your Bearer token:
```
BLUEVERSE_API_TOKEN=your_actual_bearer_token_here
```

### 3. Run the Application
```bash
python run.py
```

### 4. Open Web UI
Navigate to `http://localhost:5000` in your browser.

## Usage
1. Upload an RFP document (PDF, DOCX, or TXT)
2. Click "Create Report"
3. Wait for the 4-phase pipeline to complete
4. View results across 6 tabbed reports
5. Toggle between Formatted view and JSON view
6. All reports are also saved locally in `outputs/<run_id>/`

## Logging
- Console logs: Real-time in terminal
- File logs: `logs/rfp_analysis_YYYYMMDD.log`
- Includes timestamps, log levels, module names, and messages

## Output Files (per run)
```
outputs/<run_id>/
├── 01_RFP_Summary.txt
├── 01_RFP_Summary.json
├── 02_Oracle_Analysis.txt
├── 02_Oracle_Analysis.json
├── 03_Competitor_Analysis.txt
├── 03_Competitor_Analysis.json
├── 04_Battlecards.txt
├── 04_Battlecards.json
├── 05_Positioning_Narratives.txt
├── 05_Positioning_Narratives.json
├── 06_Go_NoGo_Report.txt
├── 06_Go_NoGo_Report.json
├── 07_Recommendation.txt
└── 07_Recommendation.json
```
