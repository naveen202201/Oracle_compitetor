"""
RFP Analysis Platform - Entry Point
Run:  python run.py
"""
from config import Config
from app import create_app

Config.init_folders()
app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
