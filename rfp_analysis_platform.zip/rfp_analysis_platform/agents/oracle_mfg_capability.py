from agents.base_agent import BaseAgent
from utils.logger_setup import get_logger

logger = get_logger("oracle_mfg_capability")


class OracleMFGCapabilityAgent(BaseAgent):
    def __init__(self):
        super().__init__("oracle_mfg_capability", "Oracle MFG Capability Agent")

    def analyze(self, rfp_summary: str) -> dict:
        prompt = (
            "You are the Oracle MFG Capability Agent. Based on the following RFP summary, "
            "provide a detailed Oracle Fusion Manufacturing capability analysis.\n"
            "Include:\n"
            "1. Relevant Oracle Fusion Manufacturing modules & features\n"
            "2. Capability mapping to RFP requirements\n"
            "3. Oracle strengths for this RFP\n"
            "4. Potential gaps or limitations\n"
            "5. Recommended Oracle solutions & accelerators\n"
            "6. Implementation considerations\n"
            "7. Oracle differentiators\n\n"
            f"RFP SUMMARY:\n{rfp_summary[:10000]}"
        )
        logger.info("Calling Oracle MFG Capability Agent...")
        response = self.call(prompt)
        content = self.extract_content(response)
        logger.info(f"Oracle MFG Capability analysis complete. Output length={len(content)} chars")
        return {
            "agent": self.display_name,
            "success": response.get("success", False),
            "content": content,
            "raw_response": response,
        }
