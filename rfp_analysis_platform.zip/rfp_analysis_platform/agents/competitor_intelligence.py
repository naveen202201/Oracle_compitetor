from agents.base_agent import BaseAgent
from utils.logger_setup import get_logger

logger = get_logger("competitor_intelligence")


class CompetitorIntelligenceAgent(BaseAgent):
    def __init__(self):
        super().__init__("competitor_intelligence", "Competitor Intelligence Agent")

    def analyze(self, rfp_summary: str) -> dict:
        prompt = (
            "You are the Competitor Intelligence Agent. Based on the following RFP summary, "
            "provide a comprehensive competitor analysis.\n"
            "Include:\n"
            "1. Key competitors likely to bid (TCS, Infosys, Accenture, Deloitte, Capgemini, IBM, etc.)\n"
            "2. Each competitor's strengths & weaknesses for this RFP\n"
            "3. Competitor pricing strategies (estimated)\n"
            "4. Competitor differentiators\n"
            "5. Market positioning of each competitor\n"
            "6. Win/loss patterns against each competitor\n"
            "7. Recommended counter-strategies\n\n"
            f"RFP SUMMARY:\n{rfp_summary[:10000]}"
        )
        logger.info("Calling Competitor Intelligence Agent...")
        response = self.call(prompt)
        content = self.extract_content(response)
        logger.info(f"Competitor Intelligence analysis complete. Output length={len(content)} chars")
        return {
            "agent": self.display_name,
            "success": response.get("success", False),
            "content": content,
            "raw_response": response,
        }
