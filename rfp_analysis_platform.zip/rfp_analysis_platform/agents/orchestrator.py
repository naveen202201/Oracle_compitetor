import json
import time
import concurrent.futures
from utils.logger_setup import get_logger
from utils.report_saver import save_report
from agents.rfp_understanding import RFPUnderstandingAgent
from agents.oracle_mfg_capability import OracleMFGCapabilityAgent
from agents.competitor_intelligence import CompetitorIntelligenceAgent
from agents.battlecard_generator import BattlecardGeneratorAgent
from agents.positioning_messaging import PositioningMessagingAgent
from agents.go_nogo import GoNoGoAgent
from agents.recommendation_outcomes import RecommendationOutcomesAgent

logger = get_logger("orchestrator")


def run_pipeline(rfp_text: str, run_id: str) -> dict:
    """Execute the full 7-agent pipeline in sequential phases."""
    pipeline_start = time.time()
    results = {}

    # == Phase 1: RFP Understanding ==
    logger.info(f"[{run_id}] == PHASE 1: RFP Understanding ==")
    agent1 = RFPUnderstandingAgent()
    rfp_result = agent1.analyze(rfp_text)
    rfp_summary = rfp_result["content"]
    save_report(run_id, "01_RFP_Summary", rfp_summary, rfp_result)
    results["rfp_summary"] = rfp_result
    logger.info(f"[{run_id}] Phase 1 complete.")

    # == Phase 2: Oracle + Competitor (parallel) ==
    logger.info(f"[{run_id}] == PHASE 2: Oracle MFG + Competitor Intelligence (parallel) ==")
    agent2 = OracleMFGCapabilityAgent()
    agent3 = CompetitorIntelligenceAgent()

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        future_oracle = executor.submit(agent2.analyze, rfp_summary)
        future_competitor = executor.submit(agent3.analyze, rfp_summary)
        oracle_result = future_oracle.result()
        competitor_result = future_competitor.result()

    oracle_analysis = oracle_result["content"]
    competitor_analysis = competitor_result["content"]
    save_report(run_id, "02_Oracle_Analysis", oracle_analysis, oracle_result)
    save_report(run_id, "03_Competitor_Analysis", competitor_analysis, competitor_result)
    results["oracle_analysis"] = oracle_result
    results["competitor_analysis"] = competitor_result
    logger.info(f"[{run_id}] Phase 2 complete.")

    # == Phase 3: Battlecard + Positioning + Go/No-Go (parallel) ==
    logger.info(f"[{run_id}] == PHASE 3: Battlecard + Positioning + Go/No-Go (parallel) ==")
    agent4 = BattlecardGeneratorAgent()
    agent5 = PositioningMessagingAgent()
    agent6 = GoNoGoAgent()

    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        future_bc = executor.submit(agent4.analyze, rfp_summary, oracle_analysis, competitor_analysis)
        future_pm = executor.submit(agent5.analyze, rfp_summary, oracle_analysis, competitor_analysis)
        future_gng = executor.submit(agent6.analyze, rfp_summary, oracle_analysis, competitor_analysis)
        bc_result = future_bc.result()
        pm_result = future_pm.result()
        gng_result = future_gng.result()

    battlecards = bc_result["content"]
    positioning = pm_result["content"]
    go_nogo = gng_result["content"]
    save_report(run_id, "04_Battlecards", battlecards, bc_result)
    save_report(run_id, "05_Positioning_Narratives", positioning, pm_result)
    save_report(run_id, "06_Go_NoGo_Report", go_nogo, gng_result)
    results["battlecards"] = bc_result
    results["positioning_narratives"] = pm_result
    results["go_nogo"] = gng_result
    logger.info(f"[{run_id}] Phase 3 complete.")

    # == Phase 4: Recommendation Outcomes ==
    logger.info(f"[{run_id}] == PHASE 4: Recommendation Outcomes ==")
    agent7 = RecommendationOutcomesAgent()
    rec_result = agent7.analyze(rfp_summary, oracle_analysis, competitor_analysis, go_nogo)
    save_report(run_id, "07_Recommendation", rec_result["content"], rec_result)
    results["recommendation"] = rec_result
    logger.info(f"[{run_id}] Phase 4 complete.")

    total_time = round(time.time() - pipeline_start, 2)
    logger.info(f"[{run_id}] == PIPELINE COMPLETE == Total time: {total_time}s")
    results["_meta"] = {"run_id": run_id, "total_seconds": total_time}
    return results
