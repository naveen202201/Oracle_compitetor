import os
from utils.logger_setup import get_logger

logger = get_logger("file_parser")


def extract_text(filepath: str) -> str:
    """Extract text from PDF, DOCX, or TXT files."""
    ext = os.path.splitext(filepath)[1].lower()
    logger.info(f"Extracting text from {filepath} (type={ext})")

    try:
        if ext == ".txt":
            with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                return f.read()

        elif ext == ".pdf":
            return _extract_pdf(filepath)

        elif ext in (".docx", ".doc"):
            return _extract_docx(filepath)

        else:
            logger.error(f"Unsupported file type: {ext}")
            raise ValueError(f"Unsupported file type: {ext}")

    except Exception as e:
        logger.error(f"Error extracting text: {e}")
        raise


def _extract_pdf(filepath: str) -> str:
    from PyPDF2 import PdfReader
    reader = PdfReader(filepath)
    pages = []
    for i, page in enumerate(reader.pages):
        text = page.extract_text()
        if text:
            pages.append(text)
        logger.debug(f"PDF page {i + 1}: {len(text) if text else 0} chars")
    full_text = "\n\n".join(pages)
    logger.info(f"PDF extraction complete: {len(reader.pages)} pages, {len(full_text)} chars")
    return full_text


def _extract_docx(filepath: str) -> str:
    from docx import Document
    doc = Document(filepath)
    paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
    # Also extract text from tables
    for table in doc.tables:
        for row in table.rows:
            row_text = " | ".join(cell.text.strip() for cell in row.cells if cell.text.strip())
            if row_text:
                paragraphs.append(row_text)
    full_text = "\n\n".join(paragraphs)
    logger.info(f"DOCX extraction complete: {len(paragraphs)} paragraphs, {len(full_text)} chars")
    return full_text
