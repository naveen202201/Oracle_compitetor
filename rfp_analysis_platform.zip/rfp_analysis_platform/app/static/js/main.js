document.addEventListener("DOMContentLoaded", () => {
    const dropZone = document.getElementById("dropZone");
    const fileInput = document.getElementById("fileInput");
    const fileNameDisplay = document.getElementById("fileName");
    const analyzeBtn = document.getElementById("analyzeBtn");
    const progressSection = document.getElementById("progressSection");
    const resultsSection = document.getElementById("resultsSection");
    const errorMsg = document.getElementById("errorMsg");
    let selectedFile = null;

    // Drag & Drop
    dropZone.addEventListener("click", () => fileInput.click());
    dropZone.addEventListener("dragover", (e) => { e.preventDefault(); dropZone.classList.add("dragover"); });
    dropZone.addEventListener("dragleave", () => dropZone.classList.remove("dragover"));
    dropZone.addEventListener("drop", (e) => {
        e.preventDefault();
        dropZone.classList.remove("dragover");
        if (e.dataTransfer.files.length) handleFile(e.dataTransfer.files[0]);
    });
    fileInput.addEventListener("change", () => { if (fileInput.files.length) handleFile(fileInput.files[0]); });

    function handleFile(file) {
        const allowed = ["application/pdf", "text/plain",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/msword"];
        if (!allowed.includes(file.type) && !file.name.match(/\.(pdf|txt|docx|doc)$/i)) {
            showError("Unsupported file type. Please upload PDF, DOCX, or TXT.");
            return;
        }
        selectedFile = file;
        fileNameDisplay.textContent = "\ud83d\udcc4 " + file.name + " (" + (file.size / 1024).toFixed(1) + " KB)";
        fileNameDisplay.style.display = "block";
        analyzeBtn.disabled = false;
        hideError();
    }

    // Analyze
    analyzeBtn.addEventListener("click", async () => {
        if (!selectedFile) return;
        analyzeBtn.disabled = true;
        analyzeBtn.innerHTML = '<span class="spinner" style="width:16px;height:16px;border-width:2px;"></span> Processing...';
        hideError();
        resultsSection.classList.remove("active");
        progressSection.classList.add("active");

        const steps = [
            { id: "step1", phases: [1] },
            { id: "step2", phases: [2] },
            { id: "step3", phases: [2] },
            { id: "step4", phases: [3] },
            { id: "step5", phases: [3] },
            { id: "step6", phases: [3] },
            { id: "step7", phases: [4] },
        ];

        // Reset steps
        steps.forEach((s) => {
            const el = document.getElementById(s.id);
            el.className = "step";
            el.querySelector(".step-status").textContent = "Pending";
            el.querySelector(".step-icon").textContent = "\u23f3";
        });

        function advancePhase(phase) {
            steps.forEach((s) => {
                if (s.phases.includes(phase)) {
                    const el = document.getElementById(s.id);
                    el.classList.add("running");
                    el.querySelector(".step-status").textContent = "Running...";
                    el.querySelector(".step-icon").innerHTML = '<div class="spinner"></div>';
                }
            });
        }

        function markPhaseDone(phase) {
            steps.forEach((s) => {
                if (s.phases.includes(phase)) {
                    const el = document.getElementById(s.id);
                    el.classList.remove("running");
                    el.classList.add("done");
                    el.querySelector(".step-status").textContent = "Complete";
                    el.querySelector(".step-icon").textContent = "\u2705";
                }
            });
        }

        // Start phase animations
        advancePhase(1);
        const phaseTimers = [
            setTimeout(() => { markPhaseDone(1); advancePhase(2); }, 4000),
            setTimeout(() => { markPhaseDone(2); advancePhase(3); }, 10000),
            setTimeout(() => { markPhaseDone(3); advancePhase(4); }, 18000),
        ];

        const formData = new FormData();
        formData.append("rfp_file", selectedFile);

        try {
            const resp = await fetch("/api/analyze", { method: "POST", body: formData });
            const data = await resp.json();
            phaseTimers.forEach(clearTimeout);

            if (data.success) {
                // Mark all done
                steps.forEach((s) => {
                    const el = document.getElementById(s.id);
                    el.className = "step done";
                    el.querySelector(".step-status").textContent = "Complete";
                    el.querySelector(".step-icon").textContent = "\u2705";
                });
                setTimeout(() => renderResults(data), 500);
            } else {
                steps.forEach((s) => {
                    const el = document.getElementById(s.id);
                    if (!el.classList.contains("done")) {
                        el.className = "step error";
                        el.querySelector(".step-status").textContent = "Failed";
                        el.querySelector(".step-icon").textContent = "\u274c";
                    }
                });
                showError(data.error || "Pipeline failed. Check logs.");
            }
        } catch (err) {
            phaseTimers.forEach(clearTimeout);
            showError("Network error: " + err.message);
        } finally {
            analyzeBtn.disabled = false;
            analyzeBtn.innerHTML = '\ud83d\ude80 Create Report';
        }
    });

    // Render Results
    function renderResults(data) {
        const results = data.results;
        const tabs = [
            { key: "competitor_analysis", label: "Competitor Analysis", icon: "\ud83d\udd0d" },
            { key: "oracle_analysis", label: "Oracle Analysis", icon: "\ud83c\udfdb\ufe0f" },
            { key: "battlecards", label: "Battlecards", icon: "\u2694\ufe0f" },
            { key: "positioning_narratives", label: "Positioning Narratives", icon: "\ud83d\udcdd" },
            { key: "go_nogo", label: "Go / No-Go", icon: "\ud83d\udea6" },
            { key: "recommendation", label: "Recommendation", icon: "\ud83c\udfaf" },
        ];

        const tabBar = document.getElementById("tabBar");
        const tabContents = document.getElementById("tabContents");
        tabBar.innerHTML = "";
        tabContents.innerHTML = "";

        tabs.forEach((tab, idx) => {
            const report = results[tab.key] || {};
            const content = report.content || "No data available.";
            const rawJson = JSON.stringify(report.raw_response || report, null, 2);

            // Tab button
            const btn = document.createElement("button");
            btn.className = "tab-btn" + (idx === 0 ? " active" : "");
            btn.textContent = tab.icon + " " + tab.label;
            btn.onclick = () => switchTab(idx);
            tabBar.appendChild(btn);

            // Tab content
            const div = document.createElement("div");
            div.className = "tab-content" + (idx === 0 ? " active" : "");
            div.id = "tab-" + idx;
            div.innerHTML =
                '<div class="report-header">' +
                    '<h3>' + tab.icon + ' ' + tab.label + '</h3>' +
                    '<div class="toggle-group">' +
                        '<button class="toggle-btn active" onclick="toggleView(' + idx + ", 'formatted', this)" + '">\ud83d\udcc4 Formatted</button>' +
                        '<button class="toggle-btn" onclick="toggleView(' + idx + ", 'json', this)" + '">{ } JSON</button>' +
                    '</div>' +
                '</div>' +
                '<div class="report-formatted" id="formatted-' + idx + '">' + formatContent(content) + '</div>' +
                '<div class="report-json" id="json-' + idx + '"><pre>' + escapeHtml(rawJson) + '</pre></div>';
            tabContents.appendChild(div);
        });

        // Meta bar
        const meta = results._meta || {};
        document.getElementById("metaRunId").textContent = meta.run_id || "-";
        document.getElementById("metaTime").textContent = meta.total_seconds ? meta.total_seconds + "s" : "-";

        resultsSection.classList.add("active");
        resultsSection.scrollIntoView({ behavior: "smooth" });
    }

    window.switchTab = function(idx) {
        document.querySelectorAll(".tab-btn").forEach((b, i) => b.classList.toggle("active", i === idx));
        document.querySelectorAll(".tab-content").forEach((c, i) => c.classList.toggle("active", i === idx));
    };

    window.toggleView = function(idx, view, btn) {
        const formatted = document.getElementById("formatted-" + idx);
        const json = document.getElementById("json-" + idx);
        const toggles = btn.parentElement.querySelectorAll(".toggle-btn");
        toggles.forEach(t => t.classList.remove("active"));
        btn.classList.add("active");
        if (view === "formatted") { formatted.style.display = "block"; json.style.display = "none"; }
        else { formatted.style.display = "none"; json.style.display = "block"; }
    };

    function formatContent(text) {
        if (!text) return "<p>No data available.</p>";
        let html = text;
        // Headers
        html = html.replace(/^#### (.+)$/gm, "<h4>$1</h4>");
        html = html.replace(/^### (.+)$/gm, "<h3>$1</h3>");
        html = html.replace(/^## (.+)$/gm, "<h2>$1</h2>");
        html = html.replace(/^# (.+)$/gm, "<h1>$1</h1>");
        // Bold
        html = html.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
        // Italic
        html = html.replace(/\*(.+?)\*/g, "<em>$1</em>");
        // Detect and convert tables (pipe-separated)
        html = convertTables(html);
        // Numbered lists
        html = html.replace(/^(\d+)\.\s+(.+)$/gm, "<li>$2</li>");
        // Bullet lists
        html = html.replace(/^[-\u2022]\s+(.+)$/gm, "<li>$1</li>");
        // Wrap consecutive <li> in <ul>
        html = html.replace(/((<li>.*?<\/li>\n?)+)/g, "<ul>$1</ul>");
        // Paragraphs for remaining lines
        html = html.split("\n\n").map(block => {
            block = block.trim();
            if (!block) return "";
            if (block.startsWith("<")) return block;
            return "<p>" + block.replace(/\n/g, "<br>") + "</p>";
        }).join("\n");
        return html;
    }

    function convertTables(text) {
        const lines = text.split("\n");
        let result = [];
        let tableRows = [];
        let inTable = false;
        for (let line of lines) {
            if (line.includes("|") && line.trim().startsWith("|")) {
                if (line.replace(/[|\-\s]/g, "").length === 0) continue;
                const cells = line.split("|").filter(c => c.trim() !== "").map(c => c.trim());
                if (cells.length >= 2) {
                    if (!inTable) { inTable = true; tableRows = []; }
                    tableRows.push(cells);
                    continue;
                }
            }
            if (inTable) {
                result.push(buildTable(tableRows));
                tableRows = [];
                inTable = false;
            }
            result.push(line);
        }
        if (inTable) result.push(buildTable(tableRows));
        return result.join("\n");
    }

    function buildTable(rows) {
        if (rows.length === 0) return "";
        let html = '<table>';
        rows.forEach((row, idx) => {
            const tag = idx === 0 ? "th" : "td";
            html += "<tr>" + row.map(c => "<" + tag + ">" + c + "</" + tag + ">").join("") + "</tr>";
        });
        html += "</table>";
        return html;
    }

    function escapeHtml(text) {
        const div = document.createElement("div");
        div.textContent = text;
        return div.innerHTML;
    }

    function showError(msg) { errorMsg.textContent = msg; errorMsg.style.display = "block"; }
    function hideError() { errorMsg.style.display = "none"; }
});
