import os
import json
import uuid
import traceback
from datetime import datetime
from flask import Blueprint, request, jsonify, render_template, current_app
from werkzeug.utils import secure_filename
from utils.file_parser import extract_text
from utils.logger_setup import get_logger
from agents.orchestrator import run_pipeline

main_bp = Blueprint("main", __name__)
logger = get_logger("routes")

ALLOWED_EXTENSIONS = {"pdf", "docx", "doc", "txt"}


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@main_bp.route("/")
def index():
    return render_template("index.html")


@main_bp.route("/api/analyze", methods=["POST"])
def analyze():
    """Accept uploaded RFP file, run the full agent pipeline, return results."""
    logger.info("=== New analysis request received ===")
    try:
        if "rfp_file" not in request.files:
            logger.warning("No file part in request")
            return jsonify({"success": False, "error": "No file uploaded."}), 400

        file = request.files["rfp_file"]
        if file.filename == "":
            logger.warning("Empty filename")
            return jsonify({"success": False, "error": "No file selected."}), 400

        if not allowed_file(file.filename):
            logger.warning(f"Invalid file type: {file.filename}")
            return jsonify({
                "success": False,
                "error": f"Unsupported file type. Allowed: {', '.join(ALLOWED_EXTENSIONS)}"
            }), 400

        # Save uploaded file
        run_id = datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6]
        filename = secure_filename(file.filename)
        upload_dir = os.path.join(current_app.config["UPLOAD_FOLDER"], run_id)
        os.makedirs(upload_dir, exist_ok=True)
        filepath = os.path.join(upload_dir, filename)
        file.save(filepath)
        logger.info(f"File saved: {filepath}")

        # Extract text
        rfp_text = extract_text(filepath)
        if not rfp_text or len(rfp_text.strip()) < 20:
            logger.error("Extracted text is too short or empty")
            return jsonify({
                "success": False,
                "error": "Could not extract meaningful text from the uploaded file."
            }), 400
        logger.info(f"Extracted {len(rfp_text)} characters from {filename}")

        # Run pipeline
        results = run_pipeline(rfp_text, run_id)
        logger.info(f"Pipeline completed for run_id={run_id}")
        return jsonify({"success": True, "run_id": run_id, "results": results})

    except Exception as e:
        logger.error(f"Unhandled error: {e}\n{traceback.format_exc()}")
        return jsonify({"success": False, "error": str(e)}), 500


@main_bp.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "timestamp": datetime.now().isoformat()})
